package tbUtilities;

/**
 * These options are used with the Use.showOptions() function.
 */
public enum Option {
    Yes, No, OK, Cancel, Closed
}
